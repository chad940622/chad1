/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int paycode; 
    double salary; 
    double hours; 
    double sales; 
    int items; 
    double wage; 

    printf("Welcome to the payroll system.\n");
    while (1)
    {
        printf("Please enter the paycode of the employee (-1 to end): ");
        scanf("%d", &paycode);
        if (paycode == -1)
        {
            break;
        }
        switch (paycode)
        {
        case 1: 
            printf("Please enter the weekly salary of the manager: ");
            scanf("%lf", &salary);
            printf("The manager's pay is $%.2f\n\n", salary);
            break;

        case 2: 
            printf("Please enter the hourly wage of the worker: ");
            scanf("%lf", &wage);
            printf("Please enter the number of hours worked by the worker: ");
            scanf("%lf", &hours);
            if (hours > 40)
            {
                salary = wage * 40 + wage * 1.5 * (hours - 40);
            }
            else
            {
                salary = wage * hours;
            }
            printf("The worker's pay is $%.2f\n\n", salary);
            break;
        case 3: 
            printf("Please enter the gross weekly sales of the worker: ");
            scanf("%lf", &sales);
            salary = 250 + sales * 0.057;
            printf("The commission worker's pay is $%.2f\n\n", salary);
            break;
        case 4: 
            printf("Please enter the number of items produced by the worker:");
            scanf("%d", &items);
            printf("Please enter the wage per item of the worker: ");
            scanf("%lf", &wage);
            salary = items * wage;
            printf("The pieceworker's pay is $%.2f\n\n", salary);
            break;

        default: 
              printf("Invalid paycode.\n\n");
        }
    }

    printf("Thank you for using the payroll system.\n");

    return 0;
}