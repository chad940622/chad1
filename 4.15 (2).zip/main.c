/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    
    double principal = 5000.0; 
    double rate; 
    double amount; 
    int year; 
    printf("%4s%21s\n", "Year", "Amount on deposit");
    for (rate = 0.1; rate <= 0.12; rate += 0.005)
    {
        printf("\nInterest rate: %.2f%%\n", rate * 100);
        for (year = 1; year <= 15; year++)
        {
            amount = principal * pow(1.0 + rate, year);

            printf("%4d%21.2f\n", year, amount);
        }
    }

    return 0;
}