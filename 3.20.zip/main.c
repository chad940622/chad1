#include <stdio.h>
int a;
float b;
float c;
int  main()
{
    printf("Enter # of hours worked (-1 to end )：");
    scanf ("%d",&a);
    if(a>-1)
    {
    printf("Enter hourly rate of the worker ($00.00)：");
    scanf("%f",&b);
    getchar();
    c=a*b;
    printf("Salary is $：%f",c);
    }
    return 0;
    
}


