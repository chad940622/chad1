/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
float a;
float b;

int main()
{
    printf("Enter sales in dollars (-1 to end)：");
    scanf("%f",&a);
    if(a>=-1)
     {
         b=200+a*0.09;
    printf("Salary is：$ %f",b); 
     }
    return 0;
}
