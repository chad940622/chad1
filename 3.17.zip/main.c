/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

int a;
int b;
int c ;
int d;
int e;
int f;
int main()
{
    
    printf ("Enter account number (-1 to end)： ");
    scanf("%d",&a);
    
    if(a>-1)
    {
    printf("Enter beginning balance：");
    scanf ("%d",&b);
    getchar();
    printf ("Enter total charges：");
    scanf ("%d",&c);
    getchar();
    printf ("Enter total credits：");
    scanf("%d",&d);
    getchar();
    printf ("Enter credit limit：");
    scanf ("%d",&e);
    getchar();
    printf ("account number=%d\n",a);
    printf ("credit limit=%d\n",e);
     f=b+c-d;
    printf ("balance=%d\n",f);
           
        }
    if (f>e)
        printf("credit limit exceeded");


    return 0;
}


