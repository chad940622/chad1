/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
float a;
float b;

int main()
{
    while(1){
    printf("Enter sales in dollars (-1 to end)：");
    scanf("%f",&a);
    if(a==-1)
        break;
    b=200+a*0.09;
    printf("Salary is：$ %.2f\n",b); 
    }
}
