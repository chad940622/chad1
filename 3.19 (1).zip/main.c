/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int a;
float b;
int c;
float d;

int main()
{
    printf("Enter loan principal (-1 to end)：");
    scanf("%d",&a);
    if(a>-1)
    {    
    printf("Enter interest rate：");
    scanf("%f",&b);
    getchar();
    printf("Enter tern of the loan in days：");
    scanf("%d",&c);
    getchar();
    d=a*b*c/365;
    printf("The interest charge is $=%f",d);
    }

    return 0;
}

