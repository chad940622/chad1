#include <stdio.h>
int a;
float b;
float c;
int  main()
{
    while(1==1){
        printf("Enter # of hours worked (-1 to end )：");
        scanf ("%d",&a);
        if (a==-1)
            break;
        if(a>40)
        {
        printf("Enter hourly rate of the worker ($00.00)：");
        scanf("%f",&b);
        getchar();
        
        c=40*b+(a-40)*b*1.5;
        printf("Salary is $：%.2f\n\n",c);
        }
        else
        {
            printf("Enter hourly rate of the worker ($00.00)：");
            scanf("%f",&b);
            getchar();
            c=a*b;
            printf("Salary is $：%.2f\n\n",c);
        }
    }
}




