/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
float a=5500;
int y;
float b;
int main()
{
    printf("輸入利率");
    scanf("%f",&b);
    for(y=0;y<=14;y++);
        {
            a=a*(1+b);
        }
printf("現有的錢是：%f",a);

    return 0;
}
