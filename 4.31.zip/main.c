/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
int a;
int b;
int main()
{
    for(a=0;a<=8;a++)
    {
        for(b=0;b<=8;b++)
        {
            if(b==4)
            printf("*");
            else if(a==1&&(b==3||b==5)||a==7&&(b==3||b==5))
            printf("*");
            else if(a==2&&(b==3||b==2||b==5||b==6)||a==6&&(b==2||b==6||b==3||b==5))
            printf("*");
            else if(a==3&&(b==1||b==6||b==3||b==7||b==2||b==5)||a==5&&(b==1||b==6||b==3||b==7||b==2||b==5))
            printf("*");
            else if(a==4&&(b==1||b==6||b==3||b==7||b==2||b==8||b==5||b==0))
            printf("*");
            else
            printf(" ");
        }
        printf("\n");
    }

    return 0;
}
